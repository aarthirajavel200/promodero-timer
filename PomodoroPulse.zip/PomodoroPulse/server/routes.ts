import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertSessionSchema, insertSettingsSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Sessions endpoints
  app.post("/api/sessions", async (req, res) => {
    try {
      const sessionData = insertSessionSchema.parse(req.body);
      const session = await storage.createSession(sessionData);
      res.json(session);
    } catch (error) {
      res.status(400).json({ message: "Invalid session data", error });
    }
  });

  app.get("/api/sessions/date/:date", async (req, res) => {
    try {
      const { date } = req.params;
      const sessions = await storage.getSessionsByDate(date);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sessions", error });
    }
  });

  app.get("/api/sessions/range/:startDate/:endDate", async (req, res) => {
    try {
      const { startDate, endDate } = req.params;
      const sessions = await storage.getSessionsInDateRange(startDate, endDate);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch sessions", error });
    }
  });

  // Settings endpoints
  app.get("/api/settings", async (req, res) => {
    try {
      const settings = await storage.getSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch settings", error });
    }
  });

  app.patch("/api/settings", async (req, res) => {
    try {
      const settingsData = insertSettingsSchema.partial().parse(req.body);
      const settings = await storage.updateSettings(settingsData);
      res.json(settings);
    } catch (error) {
      res.status(400).json({ message: "Invalid settings data", error });
    }
  });

  // Stats endpoints
  app.get("/api/stats/daily/:date", async (req, res) => {
    try {
      const { date } = req.params;
      const stats = await storage.getDailyStats(date);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch daily stats", error });
    }
  });

  app.get("/api/stats/weekly/:startDate", async (req, res) => {
    try {
      const { startDate } = req.params;
      const stats = await storage.getWeeklyStats(startDate);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch weekly stats", error });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
