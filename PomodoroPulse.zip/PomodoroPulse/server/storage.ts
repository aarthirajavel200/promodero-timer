import dotenv from "dotenv";
dotenv.config();

import mongoose from "mongoose";
import { sessions, settings, type Session, type InsertSession, type Settings, type InsertSettings, type DailyStats } from "@shared/schema";

// MongoDB Schemas
const sessionSchema = new mongoose.Schema({
  type: { type: String, required: true }, // 'work' | 'break' | 'longBreak'
  duration: { type: Number, required: true }, // duration in seconds
  completedAt: { type: Date, required: true },
  date: { type: String, required: true }, // YYYY-MM-DD format
});

const settingsSchema = new mongoose.Schema({
  workDuration: { type: Number, required: true, default: 25 }, // minutes
  shortBreakDuration: { type: Number, required: true, default: 5 }, // minutes
  longBreakDuration: { type: Number, required: true, default: 15 }, // minutes
  soundEnabled: { type: Boolean, required: true, default: true },
  sessionsUntilLongBreak: { type: Number, required: true, default: 4 },
});

const SessionModel = mongoose.model('Session', sessionSchema);
const SettingsModel = mongoose.model('Settings', settingsSchema);

export interface IStorage {
  // Connection method
  connect(): Promise<void>;
  
  // Session methods
  createSession(session: InsertSession): Promise<Session>;
  getSessionsByDate(date: string): Promise<Session[]>;
  getSessionsInDateRange(startDate: string, endDate: string): Promise<Session[]>;
  
  // Settings methods
  getSettings(): Promise<Settings>;
  updateSettings(settings: Partial<InsertSettings>): Promise<Settings>;
  
  // Stats methods
  getDailyStats(date: string): Promise<DailyStats>;
  getWeeklyStats(startDate: string): Promise<DailyStats[]>;
}

export class MemStorage implements IStorage {
  private sessions: Map<string, Session>;
  private settings: Settings;
  private sessionCounter: number;

  constructor() {
    this.sessions = new Map();
    this.sessionCounter = 1;
    
    // Default settings
    this.settings = {
      id: "1",
      workDuration: 25,
      shortBreakDuration: 5,
      longBreakDuration: 15,
      soundEnabled: true,
      sessionsUntilLongBreak: 4,
    };
  }

  async connect(): Promise<void> {
    // Memory storage doesn't need connection
    console.log('Using in-memory storage');
  }

  async createSession(insertSession: InsertSession): Promise<Session> {
    const sessionId = (this.sessionCounter++).toString();
    const session: Session = {
      ...insertSession,
      id: sessionId,
    };
    this.sessions.set(session.id, session);
    return session;
  }

  async getSessionsByDate(date: string): Promise<Session[]> {
    return Array.from(this.sessions.values()).filter(
      session => session.date === date
    );
  }

  async getSessionsInDateRange(startDate: string, endDate: string): Promise<Session[]> {
    return Array.from(this.sessions.values()).filter(
      session => session.date >= startDate && session.date <= endDate
    );
  }

  async getSettings(): Promise<Settings> {
    return this.settings;
  }

  async updateSettings(newSettings: Partial<InsertSettings>): Promise<Settings> {
    this.settings = { ...this.settings, ...newSettings };
    return this.settings;
  }

  async getDailyStats(date: string): Promise<DailyStats> {
    const sessions = await this.getSessionsByDate(date);
    
    const completedSessions = sessions.filter(s => s.type === 'work').length;
    const focusTime = sessions
      .filter(s => s.type === 'work')
      .reduce((total, s) => total + Math.floor(s.duration / 60), 0);
    const breakTime = sessions
      .filter(s => s.type === 'break' || s.type === 'longBreak')
      .reduce((total, s) => total + Math.floor(s.duration / 60), 0);
    
    return {
      date,
      completedSessions,
      focusTime,
      breakTime,
      totalSessions: sessions.length,
    };
  }

  async getWeeklyStats(startDate: string): Promise<DailyStats[]> {
    const weekStats: DailyStats[] = [];
    const start = new Date(startDate);
    
    for (let i = 0; i < 7; i++) {
      const currentDate = new Date(start);
      currentDate.setDate(start.getDate() + i);
      const dateStr = currentDate.toISOString().split('T')[0];
      
      const dailyStats = await this.getDailyStats(dateStr);
      weekStats.push(dailyStats);
    }
    
    return weekStats;
  }
}

// MongoDB Storage Implementation
export class MongoStorage implements IStorage {
  private defaultSettings: Settings = {
    id: "1",
    workDuration: 25,
    shortBreakDuration: 5,
    longBreakDuration: 15,
    soundEnabled: true,
    sessionsUntilLongBreak: 4,
  };

  async connect(): Promise<void> {
    const mongoUri = process.env.MONGO_URI;
    
    if (!mongoUri) {
      throw new Error('MONGO_URI environment variable is not set');
    }

    try {
      await mongoose.connect(mongoUri);
      console.log('Connected to MongoDB successfully');
      
      // Initialize default settings if they don't exist
      await this.initializeSettings();
    } catch (error) {
      console.error('MongoDB connection failed:', error);
      throw new Error('Failed to connect to MongoDB');
    }
  }

  private async initializeSettings(): Promise<void> {
    const existingSettings = await SettingsModel.findOne();
    if (!existingSettings) {
      await SettingsModel.create(this.defaultSettings);
      console.log('Default settings initialized');
    }
  }

  async createSession(insertSession: InsertSession): Promise<Session> {
    const session = await SessionModel.create(insertSession);
    return {
      id: session._id.toString(),
      type: session.type,
      duration: session.duration,
      completedAt: session.completedAt,
      date: session.date,
    };
  }

  async getSessionsByDate(date: string): Promise<Session[]> {
    const sessions = await SessionModel.find({ date }).sort({ completedAt: -1 });
    return sessions.map(session => ({
      id: session._id.toString(),
      type: session.type,
      duration: session.duration,
      completedAt: session.completedAt,
      date: session.date,
    }));
  }

  async getSessionsInDateRange(startDate: string, endDate: string): Promise<Session[]> {
    const sessions = await SessionModel.find({
      date: { $gte: startDate, $lte: endDate }
    }).sort({ completedAt: -1 });
    
    return sessions.map(session => ({
      id: session._id.toString(),
      type: session.type,
      duration: session.duration,
      completedAt: session.completedAt,
      date: session.date,
    }));
  }

  async getSettings(): Promise<Settings> {
    const settings = await SettingsModel.findOne();
    if (!settings) {
      // Return default settings if none exist
      return this.defaultSettings;
    }
    
    return {
      id: settings._id.toString(),
      workDuration: settings.workDuration,
      shortBreakDuration: settings.shortBreakDuration,
      longBreakDuration: settings.longBreakDuration,
      soundEnabled: settings.soundEnabled,
      sessionsUntilLongBreak: settings.sessionsUntilLongBreak,
    };
  }

  async updateSettings(newSettings: Partial<InsertSettings>): Promise<Settings> {
    const settings = await SettingsModel.findOneAndUpdate(
      {},
      newSettings,
      { new: true, upsert: true }
    );
    
    return {
      id: settings._id.toString(),
      workDuration: settings.workDuration,
      shortBreakDuration: settings.shortBreakDuration,
      longBreakDuration: settings.longBreakDuration,
      soundEnabled: settings.soundEnabled,
      sessionsUntilLongBreak: settings.sessionsUntilLongBreak,
    };
  }

  async getDailyStats(date: string): Promise<DailyStats> {
    const sessions = await this.getSessionsByDate(date);
    
    const completedSessions = sessions.filter(s => s.type === 'work').length;
    const focusTime = sessions
      .filter(s => s.type === 'work')
      .reduce((total, s) => total + Math.floor(s.duration / 60), 0);
    const breakTime = sessions
      .filter(s => s.type === 'break' || s.type === 'longBreak')
      .reduce((total, s) => total + Math.floor(s.duration / 60), 0);
    
    return {
      date,
      completedSessions,
      focusTime,
      breakTime,
      totalSessions: sessions.length,
    };
  }

  async getWeeklyStats(startDate: string): Promise<DailyStats[]> {
    const weekStats: DailyStats[] = [];
    const start = new Date(startDate);
    
    for (let i = 0; i < 7; i++) {
      const currentDate = new Date(start);
      currentDate.setDate(start.getDate() + i);
      const dateStr = currentDate.toISOString().split('T')[0];
      
      const dailyStats = await this.getDailyStats(dateStr);
      weekStats.push(dailyStats);
    }
    
    return weekStats;
  }
}

// Use MongoDB storage if MONGO_URI is provided, otherwise use memory storage
const useMongoStorage = !!process.env.MONGO_URI;

export const storage = useMongoStorage ? new MongoStorage() : new MemStorage();
