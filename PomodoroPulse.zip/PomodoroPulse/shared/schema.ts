import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(), // Changed to text to support both MongoDB ObjectId and auto-increment IDs
  type: text("type").notNull(), // 'work' | 'break' | 'longBreak'
  duration: integer("duration").notNull(), // duration in seconds
  completedAt: timestamp("completed_at").notNull(),
  date: text("date").notNull(), // YYYY-MM-DD format
});

export const settings = pgTable("settings", {
  id: text("id").primaryKey(), // Changed to text to support both MongoDB ObjectId and auto-increment IDs
  workDuration: integer("work_duration").notNull().default(25), // minutes
  shortBreakDuration: integer("short_break_duration").notNull().default(5), // minutes
  longBreakDuration: integer("long_break_duration").notNull().default(15), // minutes
  soundEnabled: boolean("sound_enabled").notNull().default(true),
  sessionsUntilLongBreak: integer("sessions_until_long_break").notNull().default(4),
});

export const insertSessionSchema = createInsertSchema(sessions).omit({
  id: true,
});

export const insertSettingsSchema = createInsertSchema(settings).omit({
  id: true,
});

export type Session = typeof sessions.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Settings = typeof settings.$inferSelect;
export type InsertSettings = z.infer<typeof insertSettingsSchema>;

// Additional types for frontend
export const timerStateSchema = z.object({
  currentMode: z.enum(['work', 'shortBreak', 'longBreak']),
  timeRemaining: z.number(),
  isRunning: z.boolean(),
  currentSession: z.number(),
  totalSessions: z.number(),
});

export type TimerState = z.infer<typeof timerStateSchema>;

export const dailyStatsSchema = z.object({
  date: z.string(),
  completedSessions: z.number(),
  focusTime: z.number(), // total focus time in minutes
  breakTime: z.number(), // total break time in minutes
  totalSessions: z.number(),
});

export type DailyStats = z.infer<typeof dailyStatsSchema>;
