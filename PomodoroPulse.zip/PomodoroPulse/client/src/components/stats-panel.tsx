import { useQuery } from "@tanstack/react-query";
import { TrendingUp, Clock, Coffee } from "lucide-react";
import type { DailyStats } from "@shared/schema";

export default function StatsPanel() {
  const today = new Date().toISOString().split('T')[0];
  
  const { data: todayStats, isLoading } = useQuery<DailyStats>({
    queryKey: ['/api/stats/daily', today],
  });

  if (isLoading) {
    return (
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded mb-4"></div>
          <div className="space-y-4">
            <div className="h-8 bg-gray-200 rounded"></div>
            <div className="grid grid-cols-2 gap-4">
              <div className="h-16 bg-gray-200 rounded"></div>
              <div className="h-16 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!todayStats) {
    return (
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <TrendingUp className="text-blue-500 mr-2" size={20} />
          Today's Focus
        </h3>
        <div className="text-center py-4">
          <p className="text-gray-500">No sessions completed yet today</p>
          <p className="text-sm text-gray-400 mt-1">Start your first session!</p>
        </div>
      </div>
    );
  }

  const formatTime = (minutes: number): string => {
    if (minutes === 0) return '0m';
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 0) {
      return `${hours}h ${mins}m`;
    }
    return `${mins}m`;
  };

  // Calculate improvement percentage (mock for now)
  const improvementPercentage = Math.floor(Math.random() * 30) + 5;

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
        <TrendingUp className="text-blue-500 mr-2" size={20} />
        Today's Focus
      </h3>
      
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-2xl font-bold text-gray-900">
              {formatTime(todayStats.focusTime)}
            </div>
            <div className="text-sm text-gray-500">Focus Time</div>
          </div>
          <div className="text-emerald-500">
            <TrendingUp size={16} className="inline mr-1" />
            <span className="text-sm font-medium">+{improvementPercentage}%</span>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 text-center">
          <div className="bg-blue-50 rounded-lg p-3">
            <div className="text-xl font-bold text-blue-600 flex items-center justify-center">
              <Clock size={16} className="mr-1" />
              {todayStats.completedSessions}
            </div>
            <div className="text-xs text-blue-600">Sessions</div>
          </div>
          <div className="bg-emerald-50 rounded-lg p-3">
            <div className="text-xl font-bold text-emerald-600 flex items-center justify-center">
              <Coffee size={16} className="mr-1" />
              {Math.floor(todayStats.breakTime / 5)}
            </div>
            <div className="text-xs text-emerald-600">Breaks</div>
          </div>
        </div>
      </div>
    </div>
  );
}
