import { Badge } from "@/components/ui/badge";
import { Briefcase, Coffee, Clock } from "lucide-react";

interface TimerDisplayProps {
  timer: {
    currentMode: 'work' | 'shortBreak' | 'longBreak';
    timeRemaining: number;
    currentSession: number;
    progressPercentage: number;
  };
}

export default function TimerDisplay({ timer }: TimerDisplayProps) {
  const formatTime = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getModeConfig = () => {
    switch (timer.currentMode) {
      case 'work':
        return {
          label: 'Focus Time',
          icon: <Briefcase size={16} />,
          bgColor: 'bg-blue-100',
          textColor: 'text-blue-800',
          strokeColor: '#3B82F6',
        };
      case 'shortBreak':
      case 'longBreak':
        return {
          label: timer.currentMode === 'longBreak' ? 'Long Break' : 'Break Time',
          icon: <Coffee size={16} />,
          bgColor: 'bg-emerald-100',
          textColor: 'text-emerald-800',
          strokeColor: '#10B981',
        };
      default:
        return {
          label: 'Focus Time',
          icon: <Briefcase size={16} />,
          bgColor: 'bg-blue-100',
          textColor: 'text-blue-800',
          strokeColor: '#3B82F6',
        };
    }
  };

  const config = getModeConfig();
  
  // Calculate stroke dash offset for progress
  const circumference = 2 * Math.PI * 112; // radius = 112
  const strokeDashoffset = circumference - (timer.progressPercentage / 100) * circumference;

  return (
    <div className="text-center mb-8">
      {/* Mode Indicator */}
      <div className="mb-6">
        <Badge className={`${config.bgColor} ${config.textColor} border-0 px-4 py-2`}>
          {config.icon}
          <span className="ml-2">{config.label}</span>
        </Badge>
      </div>

      {/* Timer Display with Progress Ring */}
      <div className="relative mb-8">
        <div className="relative w-64 h-64 mx-auto">
          <svg className="w-64 h-64 transform -rotate-90" viewBox="0 0 256 256">
            {/* Background circle */}
            <circle
              cx="128"
              cy="128"
              r="112"
              stroke="#E5E7EB"
              strokeWidth="8"
              fill="none"
            />
            {/* Progress circle */}
            <circle
              cx="128"
              cy="128"
              r="112"
              stroke={config.strokeColor}
              strokeWidth="8"
              fill="none"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              className="transition-all duration-1000 ease-linear"
            />
          </svg>
          
          {/* Timer Text */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-gray-900 mb-2">
                {formatTime(timer.timeRemaining)}
              </div>
              <div className="text-sm text-gray-500 font-medium flex items-center justify-center">
                <Clock size={14} className="mr-1" />
                Session {timer.currentSession}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
