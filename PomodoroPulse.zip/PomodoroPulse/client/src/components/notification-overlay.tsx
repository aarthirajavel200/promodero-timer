import { Button } from "@/components/ui/button";

interface NotificationOverlayProps {
  isVisible: boolean;
  type: 'work' | 'shortBreak' | 'longBreak';
  onDismiss: () => void;
}

export default function NotificationOverlay({ isVisible, type, onDismiss }: NotificationOverlayProps) {
  if (!isVisible) return null;

  const getNotificationConfig = () => {
    switch (type) {
      case 'work':
        return {
          emoji: '🍅',
          title: 'Work Session Complete!',
          message: 'Time for a well-deserved break.',
        };
      case 'shortBreak':
        return {
          emoji: '☕',
          title: 'Break Complete!',
          message: 'Ready to get back to work?',
        };
      case 'longBreak':
        return {
          emoji: '🎉',
          title: 'Long Break Complete!',
          message: 'Great job! Time for another focus session.',
        };
      default:
        return {
          emoji: '🍅',
          title: 'Session Complete!',
          message: 'Keep up the great work!',
        };
    }
  };

  const config = getNotificationConfig();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-2xl p-8 text-center max-w-sm mx-4 shadow-2xl">
        <div className="text-4xl mb-4">{config.emoji}</div>
        <h3 className="text-xl font-semibold text-gray-900 mb-2">
          {config.title}
        </h3>
        <p className="text-gray-600 mb-6">
          {config.message}
        </p>
        <Button
          onClick={onDismiss}
          className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors w-full"
        >
          Continue
        </Button>
      </div>
    </div>
  );
}
