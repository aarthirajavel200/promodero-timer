import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { SlidersHorizontal, FastForward, Play } from "lucide-react";
import type { Settings } from "@shared/schema";

interface SettingsPanelProps {
  onSkipToBreak?: () => void;
  onStartFocusSession?: () => void;
}

export default function SettingsPanel({ onSkipToBreak, onStartFocusSession }: SettingsPanelProps) {
  const { data: settings, isLoading } = useQuery<Settings>({
    queryKey: ['/api/settings'],
  });

  const [localSettings, setLocalSettings] = useState<Partial<Settings>>({});

  const updateSettingsMutation = useMutation({
    mutationFn: async (newSettings: Partial<Settings>) => {
      const response = await apiRequest("PATCH", "/api/settings", newSettings);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
      setLocalSettings({});
    },
  });

  if (isLoading || !settings) {
    return (
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded mb-4"></div>
          <div className="space-y-4">
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  const currentSettings = { ...settings, ...localSettings };

  const updateSetting = (key: keyof Settings, value: any) => {
    const newSettings = { ...localSettings, [key]: value };
    setLocalSettings(newSettings);
    updateSettingsMutation.mutate(newSettings);
  };

  return (
    <div className="space-y-6">
      {/* Settings Panel */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <SlidersHorizontal className="text-gray-500 mr-2" size={20} />
          Timer Settings
        </h3>
        
        <div className="space-y-6">
          {/* Work Duration */}
          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-2">
              Work Duration
            </Label>
            <div className="flex items-center space-x-3">
              <Slider
                value={[currentSettings.workDuration]}
                onValueChange={(value) => updateSetting('workDuration', value[0])}
                min={15}
                max={45}
                step={5}
                className="flex-1"
              />
              <span className="text-sm font-medium text-gray-900 w-12">
                {currentSettings.workDuration}min
              </span>
            </div>
          </div>
          
          {/* Short Break */}
          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-2">
              Short Break
            </Label>
            <div className="flex items-center space-x-3">
              <Slider
                value={[currentSettings.shortBreakDuration]}
                onValueChange={(value) => updateSetting('shortBreakDuration', value[0])}
                min={3}
                max={10}
                step={1}
                className="flex-1"
              />
              <span className="text-sm font-medium text-gray-900 w-12">
                {currentSettings.shortBreakDuration}min
              </span>
            </div>
          </div>
          
          {/* Long Break */}
          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-2">
              Long Break
            </Label>
            <div className="flex items-center space-x-3">
              <Slider
                value={[currentSettings.longBreakDuration]}
                onValueChange={(value) => updateSetting('longBreakDuration', value[0])}
                min={15}
                max={30}
                step={5}
                className="flex-1"
              />
              <span className="text-sm font-medium text-gray-900 w-12">
                {currentSettings.longBreakDuration}min
              </span>
            </div>
          </div>

          {/* Notification Settings */}
          <div className="pt-4 border-t border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm font-medium text-gray-700">
                  Sound Notifications
                </Label>
                <p className="text-xs text-gray-500">Play sound when sessions end</p>
              </div>
              <Switch
                checked={currentSettings.soundEnabled}
                onCheckedChange={(checked) => updateSetting('soundEnabled', checked)}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
        
        <div className="space-y-3">
          <Button
            onClick={onSkipToBreak}
            className="w-full bg-emerald-50 hover:bg-emerald-100 text-emerald-700 py-3 px-4 rounded-lg text-sm font-medium transition-colors"
            variant="outline"
          >
            <FastForward size={16} className="mr-2" />
            Skip to Break
          </Button>
          
          <Button
            onClick={onStartFocusSession}
            className="w-full bg-blue-50 hover:bg-blue-100 text-blue-700 py-3 px-4 rounded-lg text-sm font-medium transition-colors"
            variant="outline"
          >
            <Play size={16} className="mr-2" />
            Start Focus Session
          </Button>
        </div>
      </div>
    </div>
  );
}
