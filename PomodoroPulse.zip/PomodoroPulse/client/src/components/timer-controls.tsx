import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Play, Pause, RotateCcw } from "lucide-react";

interface TimerControlsProps {
  timer: {
    isRunning: boolean;
    currentSession: number;
    totalSessions: number;
    startPause: () => void;
    reset: () => void;
  };
}

export default function TimerControls({ timer }: TimerControlsProps) {
  const targetSessions = 8;
  const sessionProgress = (timer.totalSessions / targetSessions) * 100;

  return (
    <div>
      {/* Timer Controls */}
      <div className="flex items-center justify-center space-x-4 mb-6">
        <Button
          onClick={timer.startPause}
          className={`px-8 py-3 rounded-xl font-semibold text-lg transition-colors flex items-center space-x-2 ${
            timer.isRunning
              ? 'bg-red-500 hover:bg-red-600 text-white'
              : 'bg-blue-500 hover:bg-blue-600 text-white'
          }`}
        >
          {timer.isRunning ? <Pause size={20} /> : <Play size={20} />}
          <span>{timer.isRunning ? 'Pause' : 'Start'}</span>
        </Button>
        
        <Button
          onClick={timer.reset}
          variant="secondary"
          className="px-6 py-3 rounded-xl font-semibold bg-gray-200 hover:bg-gray-300 text-gray-700"
        >
          <RotateCcw size={16} className="mr-2" />
          Reset
        </Button>
      </div>

      {/* Session Progress */}
      <div className="bg-gray-50 rounded-xl p-4">
        <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
          <span>Sessions Completed Today</span>
          <span>{timer.totalSessions}/{targetSessions}</span>
        </div>
        <Progress value={sessionProgress} className="h-2" />
      </div>
    </div>
  );
}
