import { useState } from "react";
import { Clock, BarChart3, Settings } from "lucide-react";
import TimerDisplay from "@/components/timer-display";
import TimerControls from "@/components/timer-controls";
import SettingsPanel from "@/components/settings-panel";
import StatsPanel from "@/components/stats-panel";
import NotificationOverlay from "@/components/notification-overlay";
import { useTimer } from "@/hooks/use-timer";
import { Button } from "@/components/ui/button";

export default function PomodoroPage() {
  const [showStats, setShowStats] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const timer = useTimer();

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-emerald-500 rounded-lg flex items-center justify-center">
              <Clock className="text-white" size={16} />
            </div>
            <h1 className="text-xl font-semibold text-gray-900">PomodoroPulse</h1>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowStats(!showStats)}
              className="text-gray-600 hover:text-gray-900"
            >
              <BarChart3 size={20} />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowSettings(!showSettings)}
              className="text-gray-600 hover:text-gray-900"
            >
              <Settings size={20} />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Timer Section */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <TimerDisplay timer={timer} />
              <TimerControls timer={timer} />
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <StatsPanel />
            {showSettings && <SettingsPanel 
              onSkipToBreak={timer.skipToBreak}
              onStartFocusSession={timer.startFocusSession}
            />}
          </div>
        </div>

        {/* Weekly Stats - Expandable */}
        {showStats && (
          <div className="mt-8 bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                <BarChart3 className="text-gray-500 mr-2" size={20} />
                Weekly Overview
              </h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowStats(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                ×
              </Button>
            </div>
            
            <div className="grid grid-cols-7 gap-4">
              {['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'].map((day, index) => (
                <div key={day} className="text-center">
                  <div className="text-xs text-gray-500 mb-2">{day}</div>
                  <div className={`rounded-lg p-3 ${index < 4 ? 'bg-blue-100' : 'bg-gray-50'}`}>
                    <div className={`text-sm font-semibold ${index < 4 ? 'text-blue-800' : 'text-gray-400'}`}>
                      {index < 4 ? Math.floor(Math.random() * 8) + 1 : '-'}
                    </div>
                    <div className={`text-xs ${index < 4 ? 'text-blue-600' : 'text-gray-400'}`}>
                      {index < 4 ? 'sessions' : '-'}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Notification Overlay */}
      <NotificationOverlay
        isVisible={timer.showNotification}
        type={timer.currentMode}
        onDismiss={timer.dismissNotification}
      />
    </div>
  );
}
