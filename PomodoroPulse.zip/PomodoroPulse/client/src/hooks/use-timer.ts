import { useState, useEffect, useCallback, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { useAudio } from "./use-audio";
import type { Settings, TimerState } from "@shared/schema";

export function useTimer() {
  const [timerState, setTimerState] = useState<TimerState>({
    currentMode: 'work',
    timeRemaining: 25 * 60, // 25 minutes in seconds
    isRunning: false,
    currentSession: 1,
    totalSessions: 0,
  });
  
  const [showNotification, setShowNotification] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const { playNotificationSound } = useAudio();

  // Get settings
  const { data: settings } = useQuery<Settings>({
    queryKey: ['/api/settings'],
  });

  // Create session mutation
  const createSessionMutation = useMutation({
    mutationFn: async (sessionData: {
      type: string;
      duration: number;
      completedAt: Date;
      date: string;
    }) => {
      const response = await apiRequest("POST", "/api/sessions", sessionData);
      return response.json();
    },
    onSuccess: () => {
      // Invalidate stats queries
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    },
  });

  // Timer tick function
  const tick = useCallback(() => {
    setTimerState(prev => {
      if (prev.timeRemaining <= 1) {
        // Session completed
        const sessionType = prev.currentMode === 'work' ? 'work' : 
                           prev.currentMode === 'shortBreak' ? 'break' : 'longBreak';
        
        const now = new Date();
        const duration = getSessionDuration(prev.currentMode, settings);
        
        // Save completed session
        createSessionMutation.mutate({
          type: sessionType,
          duration: duration * 60,
          completedAt: now,
          date: now.toISOString().split('T')[0],
        });

        // Show notification
        setShowNotification(true);
        playNotificationSound();

        // Determine next mode
        let nextMode: TimerState['currentMode'] = 'work';
        let nextSession = prev.currentSession;
        
        if (prev.currentMode === 'work') {
          nextSession += 1;
          // Every 4th session gets a long break
          nextMode = nextSession % 4 === 0 ? 'longBreak' : 'shortBreak';
        } else {
          nextMode = 'work';
        }

        return {
          ...prev,
          currentMode: nextMode,
          timeRemaining: getSessionDuration(nextMode, settings) * 60,
          isRunning: false,
          currentSession: nextMode === 'work' ? nextSession : prev.currentSession,
          totalSessions: prev.currentMode === 'work' ? prev.totalSessions + 1 : prev.totalSessions,
        };
      }

      return {
        ...prev,
        timeRemaining: prev.timeRemaining - 1,
      };
    });
  }, [settings, createSessionMutation, playNotificationSound]);

  // Start timer interval
  useEffect(() => {
    if (timerState.isRunning) {
      intervalRef.current = setInterval(tick, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [timerState.isRunning, tick]);

  // Update timer when settings change
  useEffect(() => {
    if (settings && !timerState.isRunning) {
      setTimerState(prev => ({
        ...prev,
        timeRemaining: getSessionDuration(prev.currentMode, settings) * 60,
      }));
    }
  }, [settings, timerState.isRunning]);

  // Timer control functions
  const startPause = useCallback(() => {
    setTimerState(prev => ({
      ...prev,
      isRunning: !prev.isRunning,
    }));
  }, []);

  const reset = useCallback(() => {
    setTimerState(prev => ({
      ...prev,
      timeRemaining: getSessionDuration(prev.currentMode, settings) * 60,
      isRunning: false,
    }));
  }, [settings]);

  const skipToBreak = useCallback(() => {
    const nextMode = timerState.currentSession % 4 === 0 ? 'longBreak' : 'shortBreak';
    setTimerState(prev => ({
      ...prev,
      currentMode: nextMode,
      timeRemaining: getSessionDuration(nextMode, settings) * 60,
      isRunning: false,
    }));
  }, [timerState.currentSession, settings]);

  const startFocusSession = useCallback(() => {
    setTimerState(prev => ({
      ...prev,
      currentMode: 'work',
      timeRemaining: getSessionDuration('work', settings) * 60,
      isRunning: true,
    }));
  }, [settings]);

  const dismissNotification = useCallback(() => {
    setShowNotification(false);
  }, []);

  // Helper function to get session duration
  function getSessionDuration(mode: TimerState['currentMode'], settings?: Settings): number {
    if (!settings) return mode === 'work' ? 25 : mode === 'longBreak' ? 15 : 5;
    
    switch (mode) {
      case 'work': return settings.workDuration;
      case 'shortBreak': return settings.shortBreakDuration;
      case 'longBreak': return settings.longBreakDuration;
      default: return 25;
    }
  }

  // Calculate progress percentage
  const totalDuration = getSessionDuration(timerState.currentMode, settings) * 60;
  const progressPercentage = ((totalDuration - timerState.timeRemaining) / totalDuration) * 100;

  return {
    ...timerState,
    showNotification,
    progressPercentage,
    startPause,
    reset,
    skipToBreak,
    startFocusSession,
    dismissNotification,
  };
}
