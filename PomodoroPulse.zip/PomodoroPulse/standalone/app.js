// PomodoroPulse - Standalone Timer Application
class PomodoroTimer {
    constructor() {
        this.currentMode = 'work'; // 'work', 'shortBreak', 'longBreak'
        this.timeRemaining = 25 * 60; // 25 minutes in seconds
        this.totalTime = 25 * 60;
        this.isRunning = false;
        this.currentSession = 1;
        this.completedSessions = 0;
        this.todayStats = { sessions: 0, focusTime: 0, breaks: 0 };
        this.settings = {
            workDuration: 25,
            shortBreakDuration: 5,
            longBreakDuration: 15,
            soundEnabled: true
        };
        
        this.interval = null;
        this.loadFromStorage();
        this.bindEvents();
        this.updateDisplay();
    }

    bindEvents() {
        // Timer controls
        document.getElementById('startPauseBtn').addEventListener('click', () => this.toggleTimer());
        document.getElementById('resetBtn').addEventListener('click', () => this.resetTimer());
        
        // Settings
        document.getElementById('settingsBtn').addEventListener('click', () => this.toggleSettings());
        document.getElementById('workDuration').addEventListener('input', (e) => this.updateSetting('workDuration', parseInt(e.target.value)));
        document.getElementById('shortBreak').addEventListener('input', (e) => this.updateSetting('shortBreakDuration', parseInt(e.target.value)));
        document.getElementById('longBreak').addEventListener('input', (e) => this.updateSetting('longBreakDuration', parseInt(e.target.value)));
        document.getElementById('soundEnabled').addEventListener('change', (e) => this.updateSetting('soundEnabled', e.target.checked));
        
        // Notification
        document.getElementById('continueBtn').addEventListener('click', () => this.dismissNotification());
        
        // Stats
        document.getElementById('statsBtn').addEventListener('click', () => this.showStats());
    }

    toggleTimer() {
        this.isRunning = !this.isRunning;
        
        if (this.isRunning) {
            this.interval = setInterval(() => this.tick(), 1000);
            document.getElementById('buttonText').textContent = 'Pause';
            document.getElementById('playIcon').style.display = 'none';
            document.getElementById('pauseIcon').style.display = 'block';
        } else {
            clearInterval(this.interval);
            document.getElementById('buttonText').textContent = 'Start';
            document.getElementById('playIcon').style.display = 'block';
            document.getElementById('pauseIcon').style.display = 'none';
        }
    }

    tick() {
        this.timeRemaining--;
        
        if (this.timeRemaining <= 0) {
            this.completeSession();
        }
        
        this.updateDisplay();
    }

    completeSession() {
        this.isRunning = false;
        clearInterval(this.interval);
        
        // Update stats
        if (this.currentMode === 'work') {
            this.completedSessions++;
            this.todayStats.sessions++;
            this.todayStats.focusTime += this.settings.workDuration;
        } else {
            this.todayStats.breaks++;
        }
        
        // Play notification sound
        if (this.settings.soundEnabled) {
            this.playNotificationSound();
        }
        
        // Show notification
        this.showNotification();
        
        // Move to next session
        this.moveToNextSession();
        
        // Save to storage
        this.saveToStorage();
    }

    moveToNextSession() {
        if (this.currentMode === 'work') {
            this.currentSession++;
            // Every 4th session gets a long break
            this.currentMode = this.currentSession % 4 === 0 ? 'longBreak' : 'shortBreak';
        } else {
            this.currentMode = 'work';
        }
        
        this.resetTimer();
    }

    resetTimer() {
        this.isRunning = false;
        clearInterval(this.interval);
        
        // Set time based on current mode
        const duration = this.getCurrentModeDuration();
        this.timeRemaining = duration * 60;
        this.totalTime = duration * 60;
        
        // Reset button state
        document.getElementById('buttonText').textContent = 'Start';
        document.getElementById('playIcon').style.display = 'block';
        document.getElementById('pauseIcon').style.display = 'none';
        
        this.updateDisplay();
    }

    getCurrentModeDuration() {
        switch (this.currentMode) {
            case 'work': return this.settings.workDuration;
            case 'shortBreak': return this.settings.shortBreakDuration;
            case 'longBreak': return this.settings.longBreakDuration;
            default: return 25;
        }
    }

    updateDisplay() {
        // Update time display
        const minutes = Math.floor(this.timeRemaining / 60);
        const seconds = this.timeRemaining % 60;
        document.getElementById('timeDisplay').textContent = 
            `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        
        // Update progress ring
        const progress = ((this.totalTime - this.timeRemaining) / this.totalTime) * 100;
        const circumference = 2 * Math.PI * 112;
        const offset = circumference - (progress / 100) * circumference;
        document.getElementById('progressCircle').style.strokeDashoffset = offset;
        
        // Update mode badge and colors
        this.updateModeDisplay();
        
        // Update session number
        document.getElementById('sessionNumber').textContent = this.currentSession;
        
        // Update stats
        this.updateStatsDisplay();
        
        // Update session progress
        const sessionProgress = (this.completedSessions / 8) * 100;
        document.getElementById('sessionProgress').style.width = `${Math.min(sessionProgress, 100)}%`;
        document.getElementById('completedSessions').textContent = this.completedSessions;
    }

    updateModeDisplay() {
        const modeBadge = document.getElementById('modeBadge');
        const modeText = document.getElementById('modeText');
        const progressCircle = document.getElementById('progressCircle');
        const timerCard = document.getElementById('timerCard');
        
        if (this.currentMode === 'work') {
            modeBadge.className = 'inline-flex items-center bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium';
            modeText.textContent = 'Focus Time';
            progressCircle.setAttribute('stroke', '#3B82F6');
            timerCard.className = 'bg-white rounded-2xl shadow-lg p-8 timer-glow';
        } else {
            const isLongBreak = this.currentMode === 'longBreak';
            modeBadge.className = 'inline-flex items-center bg-emerald-100 text-emerald-800 px-4 py-2 rounded-full text-sm font-medium';
            modeText.textContent = isLongBreak ? 'Long Break' : 'Break Time';
            progressCircle.setAttribute('stroke', '#10B981');
            timerCard.className = 'bg-white rounded-2xl shadow-lg p-8 break-glow';
        }
    }

    updateStatsDisplay() {
        document.getElementById('focusTime').textContent = `${this.todayStats.focusTime}m`;
        document.getElementById('todaySessions').textContent = this.todayStats.sessions;
        document.getElementById('todayBreaks').textContent = this.todayStats.breaks;
    }

    showNotification() {
        const overlay = document.getElementById('notificationOverlay');
        const title = document.getElementById('notificationTitle');
        const message = document.getElementById('notificationMessage');
        const emoji = document.getElementById('notificationEmoji');
        
        if (this.currentMode === 'work') {
            emoji.textContent = '🍅';
            title.textContent = 'Work Session Complete!';
            message.textContent = 'Time for a well-deserved break.';
        } else if (this.currentMode === 'shortBreak') {
            emoji.textContent = '☕';
            title.textContent = 'Break Complete!';
            message.textContent = 'Ready to get back to work?';
        } else {
            emoji.textContent = '🎉';
            title.textContent = 'Long Break Complete!';
            message.textContent = 'Great job! Time for another focus session.';
        }
        
        overlay.style.display = 'flex';
    }

    dismissNotification() {
        document.getElementById('notificationOverlay').style.display = 'none';
    }

    playNotificationSound() {
        try {
            // Create a simple notification tone using Web Audio API
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            // Configure sound
            oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
            oscillator.frequency.setValueAtTime(600, audioContext.currentTime + 0.1);
            oscillator.frequency.setValueAtTime(800, audioContext.currentTime + 0.2);
            
            gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
            
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.3);
        } catch (error) {
            console.log('Audio playback not supported:', error);
        }
    }

    toggleSettings() {
        const panel = document.getElementById('settingsPanel');
        const isVisible = panel.style.display !== 'none';
        panel.style.display = isVisible ? 'none' : 'block';
        
        if (!isVisible) {
            // Update settings display
            document.getElementById('workDuration').value = this.settings.workDuration;
            document.getElementById('workDurationValue').textContent = `${this.settings.workDuration}min`;
            document.getElementById('shortBreak').value = this.settings.shortBreakDuration;
            document.getElementById('shortBreakValue').textContent = `${this.settings.shortBreakDuration}min`;
            document.getElementById('longBreak').value = this.settings.longBreakDuration;
            document.getElementById('longBreakValue').textContent = `${this.settings.longBreakDuration}min`;
            document.getElementById('soundEnabled').checked = this.settings.soundEnabled;
        }
    }

    updateSetting(key, value) {
        this.settings[key] = value;
        
        // Update display values
        if (key === 'workDuration') {
            document.getElementById('workDurationValue').textContent = `${value}min`;
            if (this.currentMode === 'work' && !this.isRunning) {
                this.resetTimer();
            }
        } else if (key === 'shortBreakDuration') {
            document.getElementById('shortBreakValue').textContent = `${value}min`;
            if (this.currentMode === 'shortBreak' && !this.isRunning) {
                this.resetTimer();
            }
        } else if (key === 'longBreakDuration') {
            document.getElementById('longBreakValue').textContent = `${value}min`;
            if (this.currentMode === 'longBreak' && !this.isRunning) {
                this.resetTimer();
            }
        }
        
        this.saveToStorage();
    }

    showStats() {
        alert(`Today's Productivity Stats:
        
Focus Time: ${this.todayStats.focusTime} minutes
Completed Sessions: ${this.todayStats.sessions}
Breaks Taken: ${this.todayStats.breaks}
Current Session: ${this.currentSession}

Keep up the great work!`);
    }

    saveToStorage() {
        const data = {
            settings: this.settings,
            todayStats: this.todayStats,
            completedSessions: this.completedSessions,
            currentSession: this.currentSession,
            date: new Date().toDateString()
        };
        localStorage.setItem('pomodoroData', JSON.stringify(data));
    }

    loadFromStorage() {
        const saved = localStorage.getItem('pomodoroData');
        if (saved) {
            const data = JSON.parse(saved);
            
            // Reset stats if it's a new day
            if (data.date !== new Date().toDateString()) {
                this.todayStats = { sessions: 0, focusTime: 0, breaks: 0 };
                this.completedSessions = 0;
                this.currentSession = 1;
            } else {
                this.todayStats = data.todayStats || { sessions: 0, focusTime: 0, breaks: 0 };
                this.completedSessions = data.completedSessions || 0;
                this.currentSession = data.currentSession || 1;
            }
            
            this.settings = { ...this.settings, ...data.settings };
        }
        
        this.resetTimer();
    }
}

// Initialize the timer when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new PomodoroTimer();
});