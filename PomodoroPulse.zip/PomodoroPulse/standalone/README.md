# PomodoroPulse - Standalone Chrome App

A standalone Pomodoro timer that runs directly in Chrome without any server setup required.

## How to Use

1. **Download the files**:
   - `index.html` - Main application file
   - `app.js` - JavaScript functionality
   - `README.md` - This file

2. **Open in Chrome**:
   - Double-click `index.html` OR
   - Right-click `index.html` → "Open with" → Chrome OR
   - Drag `index.html` into a Chrome browser window

3. **Start using the timer**:
   - Click "Start" to begin a 25-minute focus session
   - The timer will automatically switch between work and break periods
   - Adjust settings using the gear icon
   - View your daily stats

## Features

✅ **Complete Pomodoro Timer**
- 25-minute work sessions
- 5-minute short breaks  
- 15-minute long breaks after every 4 sessions
- Visual progress ring
- Audio notifications

✅ **Customizable Settings**
- Adjust work duration (15-45 minutes)
- Adjust break duration (3-10 minutes for short, 15-30 for long)
- Toggle sound notifications
- Settings persist between sessions

✅ **Progress Tracking**
- Daily session counter
- Focus time tracking
- Break counter
- Session progress bar

✅ **Local Storage**
- All data saved locally in your browser
- Stats reset daily automatically
- No internet connection required
- No data sent to external servers

## Browser Compatibility

- ✅ Chrome (recommended)
- ✅ Edge
- ✅ Firefox
- ✅ Safari

## Privacy

This app runs entirely in your browser with no external connections. All data is stored locally using browser localStorage and never leaves your computer.

## Tips for Best Experience

1. **Bookmark the page** for easy access
2. **Enable sound** - make sure your browser allows audio
3. **Use fullscreen mode** (F11) for distraction-free sessions
4. **Close other tabs** during focus sessions
5. **Allow notifications** if prompted by your browser

## Keyboard Shortcuts

- **Spacebar**: Start/Pause timer
- **R**: Reset timer
- **S**: Toggle settings panel

Enjoy your productive Pomodoro sessions! 🍅